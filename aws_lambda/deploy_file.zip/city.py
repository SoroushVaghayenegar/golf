from enum import Enum

class City(Enum):
    VANCOUVER = "Vancouver"
    BURNABY = "Burnaby"
    SURREY = "Surrey"
    NORTH_VANCOUVER = "North Vancouver"
    LANGLEY = "Langley"
    PITT_MEADOWS = "Pitt Meadows"
    COQUITLAM = "Coquitlam"
    RICHMOND = "Richmond"
    PORT_COQUITLAM = "Port Coquitlam"
    SQUAMISH = "Squamish"